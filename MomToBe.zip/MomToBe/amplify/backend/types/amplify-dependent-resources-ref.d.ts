export type AmplifyDependentResourcesAttributes = {
    "api": {
        "momtobe": {
            "GraphQLAPIKeyOutput": "string",
            "GraphQLAPIIdOutput": "string",
            "GraphQLAPIEndpointOutput": "string"
        }
    }
}