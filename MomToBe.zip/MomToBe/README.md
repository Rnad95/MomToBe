# mother-app

## Group Members 

---

- Bara’a Abu-Sara
- Hamzeh Freijat
- Hadeel Daragmeh
- Renad Al-Khawatreh
- Wesam Kandah

## Short description 

---

Our project goals to provide the new mother who faced difficulties using our App. The application will allow the user look for the blogs and take advice from another mother or see the Question and the answer of these question. Also, the application allows to the user to sell a product or buy some product that other user pushing them to the application.
