package com.example.momtobe.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.amplifyframework.datastore.generated.model.Product;
import com.bumptech.glide.Glide;
import com.example.momtobe.R;
import com.example.momtobe.ui.SliderData;

import java.util.List;

public class SliderCustomAdapter extends RecyclerView.Adapter<SliderCustomAdapter.CustomHoleder>{
    List<SliderData> sliderDataList ;
    SliderCustomAdapter.CustomClickListener listener;


    public SliderCustomAdapter(List<SliderData> sliderDataList, SliderCustomAdapter.CustomClickListener listener) {
        this.sliderDataList = sliderDataList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public SliderCustomAdapter.CustomHoleder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItemView = layoutInflater.inflate(R.layout.activity_product ,parent , false);
        return new SliderCustomAdapter.CustomHoleder(listItemView, listener);
    }

    @Override
    public void onBindViewHolder(@NonNull SliderCustomAdapter.CustomHoleder holder, int position) {

        final SliderData sliderItem = sliderDataList.get(position);

        // Glide is use to load image
        // from url in your imageview.
        Glide.with(holder.itemView)
                .load(sliderItem.getImgUrl())
                .fitCenter()
                .into(holder.imageViewBackground);

    }

    @Override
    public int getItemCount() {
        return sliderDataList.size();
    }

    static class CustomHoleder extends RecyclerView.ViewHolder {
        ImageView imageViewBackground;
        SliderCustomAdapter.CustomClickListener listener ;
        public CustomHoleder(@NonNull View itemView , SliderCustomAdapter.CustomClickListener listener) {
            super(itemView);
            this.listener = listener;

            imageViewBackground = itemView.findViewById(R.id.myimage);

            itemView.setOnClickListener(v -> listener.onTaskItemClicked(getAdapterPosition()));
        }



    }

    public interface CustomClickListener{
        void onTaskItemClicked(int position);
    }
}
