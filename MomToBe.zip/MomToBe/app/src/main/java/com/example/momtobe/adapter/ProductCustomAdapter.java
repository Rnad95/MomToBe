package com.example.momtobe.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.amplifyframework.datastore.generated.model.Product;
import com.example.momtobe.R;

import java.util.List;

public class ProductCustomAdapter extends RecyclerView.Adapter<ProductCustomAdapter.CustomHoleder> {
    List<Product> productDataList ;
    CustomClickListener listener;


    public ProductCustomAdapter(List<Product> productDataList, CustomClickListener listener) {
        this.productDataList = productDataList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CustomHoleder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItemView = layoutInflater.inflate(R.layout.activity_product ,parent , false);
        return new CustomHoleder(listItemView, listener);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomHoleder holder, int position) {
//        holder.resTitle.setText(dataList.get(position).getTitle());
//        holder.resBody.setText(dataList.get(position).getBody());
//        holder.resStatus.setText(dataList.get(position).getStatus().toString());
    }

    @Override
    public int getItemCount() {
        return productDataList.size();
    }

    static class CustomHoleder extends RecyclerView.ViewHolder {
        TextView resTitle ;
        TextView resBody ;
        TextView resStatus;
        CustomClickListener listener ;
        public CustomHoleder(@NonNull View itemView , CustomClickListener listener) {
            super(itemView);
            this.listener = listener;
//            resTitle = itemView.findViewById(R.id.resTitle);
//            resBody = itemView.findViewById(R.id.resBody);
//            resStatus = itemView.findViewById(R.id.resStatus);

            itemView.setOnClickListener(v -> listener.onTaskItemClicked(getAdapterPosition()));
        }



    }

    public interface CustomClickListener{
        void onTaskItemClicked(int position);
    }
}
